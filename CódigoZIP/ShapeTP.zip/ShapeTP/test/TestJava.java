import br.com.fatec.DataBase;
import java.sql.SQLException;

public class TestJava {
    
    public static void main(String[] args) throws ClassNotFoundException, SQLException {
        DataBase db = new DataBase();
        System.out.println("Testando...123 !");
    }
}
